'''
-----------------------------------------------------------------------
File: config.py
Creation Time: Nov 1st 2023 1:52 am
Author: Saurabh Zinjad
Developer Email: zinjadsaurabh1997@gmail.com
Copyright (c) 2023 Saurabh Zinjad. All rights reserved | GitHub: Ztrimus
-----------------------------------------------------------------------
'''
import os
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")